<footer class="footer container-fluid pl-30 pr-30">
  <div class="row">
    <div class="col-sm-12">
      <p>2018 &copy; Phoenix Group of Companies. Developed By <a href="http://www.phoenixgroup.co.in/">Phoenix Group of Companies</a>. </p>
    </div>
  </div>
</footer>
